"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../redux/authSlice";
import "../styles/Header.css";
import Image from "next/image";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const dispatch = useDispatch();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const user = useSelector((state) => state.auth.user);

  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);

    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleLogout = () => {
    dispatch(logout());
    localStorage.removeItem("isAuthenticated");
    router.push("/login");
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  if (!isMounted) {
    return null;
  }

  return (
    <header className={`header ${scrolled ? "header-scrolled" : ""}`}>
      <div className="header-container">
        <div className="header-content">
          <div className="logo-container">
            <Link href="/" className="logo">
              <span className="logo-initial">A</span>
              <span className="logo-name">Anaïs Berraki</span>
            </Link>
          </div>

          <nav className="desktop-nav">
            {isAuthenticated && (
              <>
                <Link
                  href="/"
                  className={`nav-link ${pathname === "/" ? "active" : ""}`}
                >
                  <div className="nav-link-inner">
                    <svg className="nav-icon" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M9 22V12h6v10"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span>Accueil</span>
                  </div>
                </Link>
                <Link
                  href="/projets"
                  className={`nav-link ${
                    pathname === "/projets" || pathname.startsWith("/projets/")
                      ? "active"
                      : ""
                  }`}
                >
                  <div className="nav-link-inner">
                    <svg className="nav-icon" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span>Projets</span>
                  </div>
                </Link>
                <Link
                  href="/temoignages"
                  className={`nav-link ${
                    pathname === "/temoignages" ||
                    pathname.startsWith("/temoignages/")
                      ? "active"
                      : ""
                  }`}
                >
                  <div className="nav-link-inner">
                    <svg className="nav-icon" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span>Témoignages</span>
                  </div>
                </Link>
              </>
            )}

            {isAuthenticated ? (
              <div className="auth-section">
                <div className="user-profile">
                  <div className="user-avatar">
                    <span>{user?.prenom?.charAt(0) || "U"}</span>
                  </div>
                  <span className="user-greeting">Bonjour, {user?.prenom}</span>
                </div>
                <button onClick={handleLogout} className="logout-button">
                  <svg className="logout-icon" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M16 17l5-5-5-5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M21 12H9"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Déconnexion</span>
                </button>
              </div>
            ) : (
              <div className="auth-section">
                <Link
                  href="/login"
                  className={`auth-link ${
                    pathname === "/login" ? "active" : ""
                  }`}
                >
                  <svg className="auth-icon" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M10 17l5-5-5-5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M15 12H3"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Connexion</span>
                </Link>
                <Link href="/inscription" className="signup-button">
                  <svg className="auth-icon" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <circle
                      cx="8.5"
                      cy="7"
                      r="4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line
                      x1="20"
                      y1="8"
                      x2="20"
                      y2="14"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line
                      x1="23"
                      y1="11"
                      x2="17"
                      y2="11"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Inscription</span>
                </Link>
              </div>
            )}
          </nav>

          <button
            className="mobile-menu-button"
            aria-label="Menu"
            onClick={toggleMenu}
          >
            <div className={`hamburger ${isMenuOpen ? "open" : ""}`}>
              <span className="hamburger-line"></span>
              <span className="hamburger-line"></span>
              <span className="hamburger-line"></span>
            </div>
          </button>
        </div>
        <nav className={`mobile-sidebar ${isMenuOpen ? "open" : ""}`}>
          <div className="mobile-sidebar-header">
            <div className="mobile-logo">
              <span className="logo-initial">A</span>
              <span className="logo-name">Anaïs Berraki</span>
            </div>
            <button className="close-sidebar" onClick={toggleMenu}>
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div className="mobile-nav-content">
            {isAuthenticated && (
              <div className="mobile-nav-links">
                <Link
                  href="/"
                  className={`mobile-nav-link ${
                    pathname === "/" ? "active" : ""
                  }`}
                  onClick={toggleMenu}
                >
                  <svg
                    className="mobile-nav-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M9 22V12h6v10"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Accueil</span>
                </Link>
                <Link
                  href="/projets"
                  className={`mobile-nav-link ${
                    pathname === "/projets" || pathname.startsWith("/projets/")
                      ? "active"
                      : ""
                  }`}
                  onClick={toggleMenu}
                >
                  <svg
                    className="mobile-nav-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Projets</span>
                </Link>
                <Link
                  href="/temoignages"
                  className={`mobile-nav-link ${
                    pathname === "/temoignages" ||
                    pathname.startsWith("/temoignages/")
                      ? "active"
                      : ""
                  }`}
                  onClick={toggleMenu}
                >
                  <svg
                    className="mobile-nav-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Témoignages</span>
                </Link>
              </div>
            )}

            {isAuthenticated ? (
              <div className="mobile-auth-section">
                <div className="mobile-user-profile">
                  <div className="mobile-user-avatar">
                    <span>{user?.prenom?.charAt(0) || "U"}</span>
                  </div>
                  <div className="mobile-user-greeting">
                    Bonjour, {user?.prenom}
                  </div>
                </div>
                <button onClick={handleLogout} className="mobile-logout-button">
                  <svg
                    className="mobile-auth-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M16 17l5-5-5-5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M21 12H9"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Déconnexion</span>
                </button>
              </div>
            ) : (
              <div className="mobile-auth-section">
                <Link
                  href="/login"
                  className="mobile-auth-link"
                  onClick={toggleMenu}
                >
                  <svg
                    className="mobile-auth-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M10 17l5-5-5-5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M15 12H3"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Connexion</span>
                </Link>
                <Link
                  href="/inscription"
                  className="mobile-signup-button"
                  onClick={toggleMenu}
                >
                  <svg
                    className="mobile-auth-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <circle
                      cx="8.5"
                      cy="7"
                      r="4"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line
                      x1="20"
                      y1="8"
                      x2="20"
                      y2="14"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line
                      x1="23"
                      y1="11"
                      x2="17"
                      y2="11"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Inscription</span>
                </Link>
              </div>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
}
