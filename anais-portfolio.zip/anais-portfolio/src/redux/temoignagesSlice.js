import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  temoignages: [],
};

export const temoignagesSlice = createSlice({
  name: "temoignages",
  initialState,
  reducers: {
    ajouterTemoignage: (state, action) => {
      state.temoignages.push(action.payload);
    },
    modifierTemoignage: (state, action) => {
      const index = state.temoignages.findIndex(
        (t) => t.id === action.payload.id
      );
      if (index !== -1) {
        const date = state.temoignages[index].date;
        state.temoignages[index] = {
          ...action.payload,
          date,
        };
      }
    },
  },
});

export const { ajouterTemoignage, modifierTemoignage } =
  temoignagesSlice.actions;

export default temoignagesSlice.reducer;
