"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { ajouterTemoignage } from "../../../redux/temoignagesSlice";
import Link from "next/link";
import "../../../styles/TemoignageForm.css";

export default function AjouterTemoignage() {
  const router = useRouter();
  const dispatch = useDispatch();

  const [formData, setFormData] = useState({
    nom: "",
    entreprise: "",
    message: "",
    note: 5,
  });

  const [errors, setErrors] = useState({});
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Effacer l'erreur lorsque l'utilisateur commence à corriger
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.nom.trim()) {
      newErrors.nom = "Le nom est requis";
    }

    if (!formData.entreprise.trim()) {
      newErrors.entreprise = "L'entreprise est requise";
    }

    if (!formData.message.trim()) {
      newErrors.message = "Le message est requis";
    } else if (formData.message.trim().length < 10) {
      newErrors.message = "Le message doit contenir au moins 10 caractères";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      const date = new Date().toLocaleDateString("fr-FR");

      dispatch(
        ajouterTemoignage({
          id: Date.now(),
          ...formData,
          date,
        })
      );

      router.push("/temoignages");
    }
  };

  return (
    <main className="temoignage-form-container">
      <Link href="/temoignages" className="back-link">
        &larr; Retour aux témoignages
      </Link>

      <div className="temoignage-form-card">
        <h1 className="form-title">Ajouter un témoignage</h1>

        <form onSubmit={handleSubmit} className="temoignage-form">
          <div className="form-group">
            <label htmlFor="nom" className="form-label">
              Nom
            </label>
            <input
              type="text"
              id="nom"
              name="nom"
              value={formData.nom}
              onChange={handleChange}
              className={`form-input ${errors.nom ? "error" : ""}`}
            />
            {errors.nom && <p className="error-message">{errors.nom}</p>}
          </div>

          <div className="form-group">
            <label htmlFor="entreprise" className="form-label">
              Entreprise / Poste
            </label>
            <input
              type="text"
              id="entreprise"
              name="entreprise"
              value={formData.entreprise}
              onChange={handleChange}
              className={`form-input ${errors.entreprise ? "error" : ""}`}
            />
            {errors.entreprise && (
              <p className="error-message">{errors.entreprise}</p>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="message" className="form-label">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="5"
              className={`form-textarea ${errors.message ? "error" : ""}`}
            ></textarea>
            {errors.message && (
              <p className="error-message">{errors.message}</p>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="note" className="form-label">
              Note
            </label>
            <div className="rating-selector">
              {[1, 2, 3, 4, 5].map((value) => (
                <label key={value} className="rating-label">
                  <input
                    type="radio"
                    name="note"
                    value={value}
                    checked={Number.parseInt(formData.note) === value}
                    onChange={handleChange}
                    className="rating-input"
                  />
                  <span
                    className={`star ${
                      Number.parseInt(formData.note) >= value ? "filled" : ""
                    }`}
                  >
                    ★
                  </span>
                </label>
              ))}
            </div>
          </div>

          <button type="submit" className="submit-button">
            Soumettre le témoignage
          </button>
        </form>
      </div>
    </main>
  );
}
