"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import Link from "next/link";
import "../../styles/Temoignages.css";

export default function Temoignages() {
  const router = useRouter();
  const temoignages = useSelector((state) => state.temoignages.temoignages);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  return (
    <main className="temoignages-container">
      <div className="temoignages-header">
        <h1 className="page-title">Témoignages</h1>
        <Link href="/temoignages/ajouter" className="add-temoignage-button">
          Ajouter un témoignage
        </Link>
      </div>

      {temoignages.length === 0 ? (
        <div className="no-temoignages">
          <p className="no-temoignages-text">
            Aucun témoignage pour le moment.
          </p>
          <p className="no-temoignages-subtext">
            Soyez le premier à laisser un témoignage !
          </p>
        </div>
      ) : (
        <div className="temoignages-grid">
          {temoignages.map((temoignage) => (
            <div key={temoignage.id} className="temoignage-card">
              <div className="temoignage-header">
                <div className="temoignage-author">
                  <h2 className="temoignage-name">{temoignage.nom}</h2>
                  <p className="temoignage-company">{temoignage.entreprise}</p>
                </div>
                <div className="temoignage-actions">
                  <Link
                    href={`/temoignages/modifier/${temoignage.id}`}
                    className="edit-link"
                  >
                    Modifier
                  </Link>
                </div>
              </div>

              <p className="temoignage-message">{temoignage.message}</p>

              <div className="temoignage-footer">
                <div className="temoignage-rating">
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className={`star ${i < temoignage.note ? "filled" : ""}`}
                    >
                      ★
                    </span>
                  ))}
                </div>
                <span className="temoignage-date">{temoignage.date}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
