"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import Link from "next/link";
import Image from "next/image";
import "../../styles/Projets.css";

export default function Projets() {
  const router = useRouter();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  const projets = [
    {
      id: 1,
      titre: "SocialConnect - Réseau Social",
      description:
        "Plateforme de réseau social permettant aux utilisateurs de créer des profils, partager du contenu, et interagir avec d'autres utilisateurs via des commentaires et des messages directs.",
      image: "/social.webp",
      technologies: ["React", "Firebase", "Redux", "Material UI"],
      featured: true,
    },
    {
      id: 2,
      titre: "EcoShop - E-commerce Durable",
      description:
        "Marketplace pour produits écologiques avec système de paiement sécurisé, authentification, et gestion des commandes. Focus sur l'expérience utilisateur et la performance.",
      image: "/ecommerce.png",
      technologies: ["Next.js", "Stripe", "MongoDB", "Tailwind CSS"],
      featured: false,
    },
  ];

  return (
    <main className="projets-container">
      <h1 className="page-title">Mes Projets</h1>

      <div className="projets-filter">
        <h2 className="filter-title">Projets à la une</h2>
      </div>

      <div className="projets-featured">
        {projets
          .filter((projet) => projet.featured)
          .map((projet) => (
            <div key={projet.id} className="projet-card featured">
              <div className="projet-image">
                <div className="featured-badge">À la une</div>
                <Image
                  src={projet.image || "/placeholder.svg"}
                  alt={projet.titre}
                  width={500}
                  height={300}
                  priority={true}
                />
              </div>

              <div className="projet-content">
                <h2 className="projet-title">{projet.titre}</h2>
                <p className="projet-description">{projet.description}</p>

                <div className="projet-technologies">
                  <h3 className="technologies-title">
                    Technologies utilisées:
                  </h3>
                  <div className="technologies-list">
                    {projet.technologies.map((tech, index) => (
                      <span key={index} className="technology-tag">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <Link
                  href={`/projets/${projet.id}`}
                  className="view-details-button"
                >
                  Voir les détails
                </Link>
              </div>
            </div>
          ))}
      </div>

      <div className="projets-filter">
        <h2 className="filter-title">Tous les projets</h2>
      </div>

      <div className="projets-grid">
        {projets.map((projet) => (
          <div key={projet.id} className="projet-card">
            <div className="projet-image">
              {projet.featured && (
                <div className="featured-badge-small">À la une</div>
              )}
              <Image
                src={projet.image || "/placeholder.svg"}
                alt={projet.titre}
                width={500}
                height={300}
              />
            </div>

            <div className="projet-content">
              <h2 className="projet-title">{projet.titre}</h2>
              <p className="projet-description">{projet.description}</p>

              <div className="projet-technologies">
                <h3 className="technologies-title">Technologies utilisées:</h3>
                <div className="technologies-list">
                  {projet.technologies.map((tech, index) => (
                    <span key={index} className="technology-tag">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <Link
                href={`/projets/${projet.id}`}
                className="view-details-button"
              >
                Voir les détails
              </Link>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
