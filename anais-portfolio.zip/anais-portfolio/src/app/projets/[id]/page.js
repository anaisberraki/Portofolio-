"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import Image from "next/image";
import Link from "next/link";
import "../../../styles/ProjetDetail.css";

export default function ProjetDetail({ params }) {
  const router = useRouter();
  const { id } = params;
  const [projet, setProjet] = useState(null);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
      return;
    }

    if (id) {
      // Simuler une récupération de données
      const projets = [
        {
          id: 1,
          titre: "SocialConnect - Réseau Social",
          description:
            "Plateforme de réseau social permettant aux utilisateurs de créer des profils, partager du contenu, et interagir avec d'autres utilisateurs via des commentaires et des messages directs.",
          descriptionLongue:
            "SocialConnect est une plateforme de réseau social moderne et intuitive que j'ai développée pour permettre aux utilisateurs de se connecter et d'interagir de manière significative. L'application offre une expérience utilisateur fluide avec une interface réactive et des fonctionnalités sociales complètes. Les utilisateurs peuvent créer des profils personnalisés, publier divers types de contenu (texte, images, vidéos), et interagir via des commentaires, des likes et des messages directs. La plateforme inclut également des fonctionnalités de notifications en temps réel et un flux d'actualités personnalisé basé sur les préférences et les connexions de l'utilisateur.",
          image: "/social.webp",
          technologies: ["React", "Firebase", "Redux", "Material UI"],
          fonctionnalites: [
            "Authentification et profils personnalisables",
            "Publication multimédia (texte, images, vidéos)",
            "Système de commentaires et réactions",
            "Messagerie privée en temps réel",
            "Notifications et fils d'actualité personnalisés",
            "Mode sombre/clair adaptable",
          ],
          github: "https://github.com/anaisberraki",
          featured: true,
        },
        {
          id: 2,
          titre: "EcoShop - E-commerce Durable",
          description:
            "Marketplace pour produits écologiques avec système de paiement sécurisé, authentification, et gestion des commandes. Focus sur l'expérience utilisateur et la performance.",
          descriptionLongue:
            "EcoShop est une plateforme e-commerce spécialisée dans les produits écologiques et durables. Cette application web offre une expérience d'achat complète, depuis la découverte de produits jusqu'au paiement sécurisé. J'ai accordé une attention particulière à l'optimisation des performances et à l'expérience utilisateur, avec un design responsive qui s'adapte à tous les appareils. Le système de gestion de contenu intégré permet aux administrateurs de gérer facilement l'inventaire, les catégories et les commandes. L'intégration de Stripe assure des transactions sécurisées, tandis que l'authentification multi-niveaux protège les données des utilisateurs.",
          image: "/ecommerce.png",
          technologies: ["Next.js", "Stripe", "MongoDB", "Tailwind CSS"],
          fonctionnalites: [
            "Catalogue de produits avec filtres avancés",
            "Panier d'achat et liste de souhaits",
            "Paiement sécurisé via Stripe",
            "Système de compte utilisateur et historique des commandes",
            "Tableau de bord administrateur pour la gestion des produits",
            "Optimisation SEO et partage sur les réseaux sociaux",
          ],
          github: "https://github.com/anaisberraki",

          featured: true,
        },
      ];

      const projetTrouve = projets.find((p) => p.id === Number.parseInt(id));
      setProjet(projetTrouve);
    }
  }, [id, router]);

  if (!projet) {
    return <div className="loading">Chargement...</div>;
  }

  return (
    <main className="projet-detail-container">
      <Link href="/projets" className="back-link">
        &larr; Retour aux projets
      </Link>

      <div className="projet-detail-card">
        <div className="projet-detail-image">
          <Image
            src={projet.image || "/placeholder.svg"}
            alt={projet.titre}
            width={800}
            height={500}
          />
        </div>

        <div className="projet-detail-content">
          <h1 className="projet-detail-title">{projet.titre}</h1>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Description</h2>
            <p className="projet-detail-description">
              {projet.descriptionLongue}
            </p>
          </div>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Technologies utilisées</h2>
            <div className="technologies-list">
              {projet.technologies.map((tech, index) => (
                <span key={index} className="technology-tag">
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Fonctionnalités</h2>
            <ul className="features-list">
              {projet.fonctionnalites.map((fonc, index) => (
                <li key={index} className="feature-item">
                  {fonc}
                </li>
              ))}
            </ul>
          </div>

          <div className="projet-links">
            <a
              href={projet.github}
              target="_blank"
              rel="noopener noreferrer"
              className="github-link"
            >
              Voir sur GitHub
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
