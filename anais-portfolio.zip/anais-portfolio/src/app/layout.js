import { Poppins } from "next/font/google";
import "../styles/globals.css";
import { ReduxProvider } from "../redux/provider";
import Header from "../components/Header";
import Footer from "../components/Footer";
import "../styles/Layout.css";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
});

export const metadata = {
  title: "Anais Berraki",
  description: "Portfolio d'Anais Berraki",
};

export default function RootLayout({ children }) {
  return (
    <html>
      <body className={poppins.className}>
        <ReduxProvider>
          <div className="layout">
            <Header />
            <div className="main-content">{children}</div>
            <Footer />
          </div>
        </ReduxProvider>
      </body>
    </html>
  );
}
