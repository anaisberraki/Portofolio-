"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import Image from "next/image";
import Link from "next/link";
import "../styles/Home.css";

export default function Home() {
  const router = useRouter();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  return (
    <main className="home-container">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-bg-pattern"></div>
        <div className="hero-content">
          <div className="hero-text">
            <span className="hero-greeting">Bonjour, je suis</span>
            <h1 className="hero-name">Anaïs Berraki</h1>
            <h2 className="hero-title">
              Développeuse Web & Programmeuse Informatique
            </h2>
            <p className="hero-description">
              Passionnée par le développement logiciel et les technologies du
              numérique. Je crée des solutions web modernes, intuitives et
              performantes.
            </p>
            <div className="hero-cta">
              <Link href="/projets" className="cta-primary">
                Voir mes projets
              </Link>
              <Link
                href="https://ca.linkedin.com/in/anais-berraki-81abb835a"
                className="cta-secondary"
                target="_blank"
              >
                Me contacter
              </Link>
            </div>
          </div>
          <div className="hero-image-container">
            <div className="hero-image-wrapper">
              <div className="hero-image-bg"></div>
              <div className="hero-image">
                <Image
                  src="/image.jpg"
                  alt="Anaïs Berraki"
                  width={150}
                  height={150}
                  priority
                  style={{ objectFit: "cover", width: "100%", height: "100%" }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about-section">
        <div className="about-content">
          <div className="section-heading">
            <span className="section-subtitle">À propos de moi</span>
            <h2 className="section-title">Qui suis-je ?</h2>
          </div>

          <div className="about-grid">
            <div className="about-text">
              <p className="about-description">
                Je m&apos;appelle Anaïs Berraki, j&apos;ai 21 ans et je suis
                diplômée en programmation informatique du Collège La Cité.
                Originaire d&apos;Algérie, je suis passionnée par les
                technologies numériques et le développement web.
              </p>
              <p className="about-description">
                Fraîchement diplômée, je suis à la recherche d&apos;opportunités
                me permettant d&apos;appliquer mes compétences et de continuer à
                développer mon expertise. Mon parcours académique m&apos;a
                permis d&apos;acquérir une solide base technique et une
                méthodologie rigoureuse que je souhaite mettre à profit dans des
                projets innovants.
              </p>
              <p className="about-description">
                Créative, analytique et déterminée, j&apos;aime relever de
                nouveaux défis et apprendre continuellement. Mon objectif est de
                contribuer à des projets significatifs où je pourrai allier ma
                passion pour la technologie avec mon désir d&apos;innovation.
              </p>

              <div className="about-stats">
                <div className="stat-item">
                  <p className="stat-number">2+</p>
                  <p className="stat-label">Années d'expérience</p>
                </div>
                <div className="stat-item">
                  <p className="stat-number">10+</p>
                  <p className="stat-label">Projets réalisés</p>
                </div>
              </div>
            </div>

            <div className="about-image-container">
              <Image
                src="/image.jpg"
                alt="Anaïs Berraki"
                width={500}
                height={600}
                style={{ width: "100%", height: "auto", objectFit: "cover" }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="skills-section">
        <div className="skills-content">
          <div className="section-heading">
            <span className="section-subtitle">Ce que je maîtrise</span>
            <h2 className="section-title">Mes compétences</h2>
          </div>

          <div className="skills-grid">
            <div className="skill-card">
              <svg
                className="skill-icon"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                <path d="M2 17l10 5 10-5"></path>
                <path d="M2 12l10 5 10-5"></path>
              </svg>
              <h3 className="skill-title">Développement Frontend</h3>
              <ul className="skill-list">
                <li>HTML5, CSS3, JavaScript</li>
                <li>React.js, Next.js</li>
                <li>Tailwind CSS, SCSS</li>
                <li>UI/UX Design Principles</li>
              </ul>
            </div>

            <div className="skill-card">
              <svg
                className="skill-icon"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                <line x1="6" y1="6" x2="6.01" y2="6"></line>
                <line x1="6" y1="18" x2="6.01" y2="18"></line>
              </svg>
              <h3 className="skill-title">Développement Backend</h3>
              <ul className="skill-list">
                <li>Node.js, Express</li>
                <li>MongoDB, PostgreSQL</li>
                <li>API RESTful</li>
                <li>GraphQL Basics</li>
              </ul>
            </div>

            <div className="skill-card">
              <svg
                className="skill-icon"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                <polyline points="2 17 12 22 22 17"></polyline>
                <polyline points="2 12 12 17 22 12"></polyline>
              </svg>
              <h3 className="skill-title">Outils & Méthodologies</h3>
              <ul className="skill-list">
                <li>Git, GitHub</li>
                <li>VS Code, Figma</li>
                <li>Méthodologie Agile/Scrum</li>
                <li>Tests Unitaires (Jest)</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Project Preview Section */}
      <section className="projects-preview-section">
        <div className="projects-preview-content">
          <div className="section-heading">
            <span className="section-subtitle">Découvrez mes réalisations</span>
            <h2 className="section-title">Projets récents</h2>
          </div>

          <div className="preview-grid">
            <div className="preview-card">
              <div className="preview-image-container">
                <Image
                  src="/projet-gestion-taches.png"
                  alt="Portfolio Personnel en Next.js"
                  width={400}
                  height={200}
                  className="preview-image"
                />
              </div>
              <div className="preview-content">
                <h3 className="preview-title">
                  Portfolio Personnel en Next.js
                </h3>
                <p className="preview-description">
                  Un portfolio moderne et responsive créé avec Next.js et des
                  animations CSS personnalisées.
                </p>
                <div className="preview-technologies">
                  <span className="preview-tech">Next.js</span>
                  <span className="preview-tech">React</span>
                  <span className="preview-tech">CSS Modules</span>
                </div>
                <Link href="/projets/1" className="preview-link">
                  Voir le projet
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </Link>
              </div>
            </div>

            <div className="preview-card">
              <div className="preview-image-container">
                <Image
                  src="/ecommerce-projet.png"
                  alt="Application de Recettes Culinaires"
                  width={400}
                  height={200}
                  className="preview-image"
                />
              </div>
              <div className="preview-content">
                <h3 className="preview-title">Application de Recettes</h3>
                <p className="preview-description">
                  Une application web pour découvrir, sauvegarder et partager
                  des recettes de cuisine.
                </p>
                <div className="preview-technologies">
                  <span className="preview-tech">React</span>
                  <span className="preview-tech">Node.js</span>
                  <span className="preview-tech">MongoDB</span>
                </div>
                <Link href="/projets/2" className="preview-link">
                  Voir le projet
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </Link>
              </div>
            </div>

            <div className="preview-card">
              <div className="preview-image-container">
                <Image
                  src="/projet-meteo.webp"
                  alt="Dashboard Analytics"
                  width={400}
                  height={200}
                  className="preview-image"
                />
              </div>
              <div className="preview-content">
                <h3 className="preview-title">Dashboard Analytics</h3>
                <p className="preview-description">
                  Un tableau de bord interactif pour visualiser des données
                  analytiques avec graphiques.
                </p>
                <div className="preview-technologies">
                  <span className="preview-tech">Vue.js</span>
                  <span className="preview-tech">D3.js</span>
                  <span className="preview-tech">Express</span>
                </div>
                <Link href="/projets/3" className="preview-link">
                  Voir le projet
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA Section */}
      <section className="contact-cta-section">
        <div className="contact-cta-content">
          <h2 className="cta-heading">Intéressé(e) par une collaboration ?</h2>
          <p className="cta-subheading">
            Je suis actuellement disponible pour des opportunités de travail.
            N'hésitez pas à me contacter pour discuter de votre projet.
          </p>
          <Link
            href="https://ca.linkedin.com/in/anais-berraki-81abb835a"
            className="cta-button"
            target="_blank"
          >
            Me contacter
          </Link>
        </div>
      </section>
    </main>
  );
}
