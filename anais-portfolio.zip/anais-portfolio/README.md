# Portfolio d'Anais

## 🌟 Présentation

Un site portfolio moderne développé avec Next.js, Redux . Cette plateforme met en valeur les projets professionnels, présente des témoignages clients et offre un système d'authentification.

## 🛠️ Technologies utilisées

- **Framework Frontend**: Next.js 15
- **Bibliothèque UI**: React 19
- **Gestion d'état**: Redux Toolkit avec Redux Persist
- **Styles**: CSS personnalisé
- **Authentification**: Système personnalisé

## 📸 Aperçu du site

<div align="center">
  <h3>Page d'Accueil</h3>
  <img src="public/captures/accueil.png" alt="Page d'accueil" width="600"/>
  <p><em>Présentation principale avec mise en avant des projets</em></p>
  
  <h3>Catalogue de Projets</h3>
  <img src="public/captures/liste-projets.png" alt="Liste des projets" width="600"/>
  <p><em>Visualisation de l'ensemble du portfolio</em></p>
  
  <h3>Détail d'un Projet</h3>
  <img src="public/captures/detail-projet.png" alt="Détail d'un projet" width="600"/>
  <p><em>Présentation approfondie avec technologies et fonctionnalités</em></p>
  
  <h3>Témoignages Clients</h3>
  <img src="public/captures/temoignages.png" alt="Témoignages" width="600"/>
  <p><em>Avis et retours d'expérience des clients</em></p>
</div>

## ✨ Fonctionnalités principales

| Fonctionnalité      | Description                                                  |
| ------------------- | ------------------------------------------------------------ |
| Design Responsive   | Optimisé pour tous les appareils (mobile, tablette, desktop) |
| Gestion de Projets  | Affichage, filtrage et détails des réalisations              |
| Section Témoignages | Consultation, ajout et modification des témoignages clients  |
| Authentification    | Système de connexion et d'inscription sécurisé               |
| Gestion d'État      | Utilisation de Redux avec persistance des données            |

## 🚀 Démarrage rapide

### Prérequis

- Node.js 18 ou supérieur
- Gestionnaire de paquets (npm, yarn, pnpm ou bun)

### Installation

```bash
# Cloner le dépôt
git clone <url-du-dépôt>
cd anais-portfolio

# Installer les dépendances
npm install
# ou avec yarn
yarn

# Lancer le serveur de développement
npm run dev
```

Ouvrez ensuite [http://localhost:3000](http://localhost:3000) dans votre navigateur pour voir le site.

## 📁 Structure du projet

```
anais-portfolio/
├── public/           # Ressources statiques
│   └── captures/     # Captures d'écran
├── src/
│   ├── app/          # Pages et routage
│   ├── components/   # Composants réutilisables
│   ├── redux/        # Gestion d'état
│   └── styles/       # Feuilles de style CSS
└── README.md         # Documentation
```

## 🔄 Configuration Redux

Le projet utilise Redux pour la gestion d'état avec redux-persist pour maintenir l'état entre les sessions :

- `authSlice` : Gestion de l'authentification
- `temoignagesSlice` : Gestion des témoignages
- Les données Redux sont persistées dans le localStorage

## Deployment

```bash
npm run build
npm run start
```
